site: firstapp start door playknop rechtsboven
arduino finalq: op com8 uploaden
nodejs: in terminal "node app" hier worden de serialwrites gelogd

herstarten:
--ctrl+c in nodejs terminal en opnieuw "node app"
--refresh pagina http://localhost:8080/solve?combo=qrgfidejpoipeqpenpbnq
	of send opnieuw nieuwe data via website